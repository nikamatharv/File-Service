package com.colan.FileService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FileServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
