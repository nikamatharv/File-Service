package com.colan.FileService.controller;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.colan.FileService.model.FileMetadata;
import com.colan.FileService.service.FileService;

@RestController
@RequestMapping("/files")
public class FileController {

    private final FileService fileService;

    public FileController(FileService fileService) {
        this.fileService = fileService;
    }

    // Endpoint to upload file
    @PostMapping("/upload")
    public ResponseEntity<FileMetadata> uploadFile(@RequestParam("file") MultipartFile file) throws IOException {
        FileMetadata fileMetadata = fileService.uploadFile(file);
        return ResponseEntity.ok(fileMetadata);
    }

    // Endpoint to list all uploaded files
    @GetMapping("/list")
    public List<FileMetadata> listFiles() {
        return fileService.listFiles();
    }

    // Endpoint to download file by ID
    @GetMapping("/download/{id}")
    public ResponseEntity<byte[]> downloadFile(@PathVariable Long id) throws IOException {
        FileMetadata fileMetadata = fileService.getFileMetadata(id);
        byte[] fileContent = Files.readAllBytes(Paths.get(fileMetadata.getPath()));
        return ResponseEntity.ok().header("Content-Type", fileMetadata.getFileType())
                .header("Content-Disposition", "attachment; filename=\"" + fileMetadata.getFileName() + "\"")
                .body(fileContent);
    }

    // Endpoint to delete file by ID
    @DeleteMapping("/delete/{id}")
    public ResponseEntity<String> deleteFile(@PathVariable Long id) throws IOException {
        fileService.deleteFile(id);
        return ResponseEntity.ok("File deleted successfully");
    }
}
