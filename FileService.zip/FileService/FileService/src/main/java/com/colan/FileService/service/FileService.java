package com.colan.FileService.service;



import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.colan.FileService.model.FileMetadata;
import com.colan.FileService.repository.FileMetadataRepository;

@Service
public class FileService {

    @Value("${file.upload-dir}")
    private String uploadDir;

    private final FileMetadataRepository repository;

    public FileService(FileMetadataRepository repository) {
        this.repository = repository;
    }

    public FileMetadata uploadFile(MultipartFile file) throws IOException {
        // Validate file type
        if (!file.getContentType().startsWith("image") && !file.getContentType().equals("application/pdf")) {
            throw new IllegalArgumentException("Invalid file type");
        }

        UUID id = null;
		// Save file locally
        String fileName = id.randomUUID().toString() + "_" + file.getOriginalFilename();
        String filePath = uploadDir + File.separator + fileName;
        File dest = new File(filePath);
        file.transferTo(dest);

        // Save file metadata to the database
        FileMetadata fileMetadata = new FileMetadata();
        fileMetadata.setFileName(file.getOriginalFilename());
        fileMetadata.setFileType(file.getContentType());
        fileMetadata.setSize(file.getSize());
        fileMetadata.setPath(filePath);

        return repository.save(fileMetadata);
    }

    public FileMetadata getFileMetadata(Long id) {
        return repository.findById(id).orElseThrow(() -> new RuntimeException("File not found"));
    }

    public void deleteFile(Long id) throws IOException {
        FileMetadata fileMetadata = getFileMetadata(id);
        File file = new File(fileMetadata.getPath());
        if (file.delete()) {
            repository.delete(fileMetadata);
        } else {
            throw new IOException("Failed to delete the file");
        }
    }

	public List<FileMetadata> listFiles() {
		// TODO Auto-generated method stub
		return null;
	}
}
