// Upload file
document.getElementById('uploadForm').addEventListener('submit', function (event) {
    event.preventDefault();

    const fileInput = document.getElementById('file');
    const formData = new FormData();
    formData.append('file', fileInput.files[0]);

    fetch('/files/upload', {
        method: 'POST',
        body: formData
    })
    .then(response => response.text())  // Get raw response as text
    .then(text => {
        if (text) {
            try {
                const data = JSON.parse(text);  // Parse the response as JSON
                alert('File uploaded successfully!');
                loadFiles(); // Reload the list of files
            } catch (error) {
                alert('Error parsing response: ' + error);
            }
        } else {
            alert('Empty response from the server.');
        }
    })
    .catch(error => alert('Error uploading file: ' + error));
});

// Load file list
function loadFiles() {
    fetch('/files/list')
        .then(response => response.json())
        .then(data => {
            const fileList = document.getElementById('fileList');
            fileList.innerHTML = '';

            data.forEach(file => {
                const li = document.createElement('li');
                li.innerHTML = `
                    <span>${file.fileName} (${file.fileType}, ${file.size} bytes)</span>
                    <button onclick="downloadFile(${file.id})">Download</button>
                    <button onclick="deleteFile(${file.id})">Delete</button>
                `;
                fileList.appendChild(li);
            });
        })
        .catch(error => alert('Error loading files: ' + error));
}


// Delete file
function deleteFile(id) {
    fetch(`/files/delete/${id}`, {
        method: 'DELETE'
    })
    .then(response => response.text())  // Get raw response as text
    .then(text => {
        if (text) {
            try {
                const data = JSON.parse(text);
                alert('File deleted successfully');
                loadFiles(); // Reload the list of files
            } catch (error) {
                alert('Error parsing response: ' + error);
            }
        } else {
            alert('Empty response from the server.');
        }
    })
    .catch(error => alert('Error deleting file: ' + error));
}


// Load files initially
loadFiles();
